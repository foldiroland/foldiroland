function kiir1(name, message) {
    console.log(message + " " + (name)());
 }
 

 let name = "Földi Roland";
 let message = "Üdv";
 
 
 kiir1(()=>{return name}, message);
 